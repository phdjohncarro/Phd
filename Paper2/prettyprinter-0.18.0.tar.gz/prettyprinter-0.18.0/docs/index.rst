Welcome to PrettyPrinter's documentation!
=========================================

.. include:: ../README.rst

User Guide
----------

.. toctree::
   :maxdepth: 2

   usage

API Reference
-------------

.. toctree::
   :maxdepth: 2

   api_reference

Meta
----
.. toctree::
   :maxdepth: 1
   
   authors
   history
