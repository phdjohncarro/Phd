=======
Credits
=======

* Tommi Kaikkonen
* GitHub user `Cologler <https://github.com/Cologler/>`_
* GitHub user `johnnoone <https://github.com/johnnoone/>`_
* GitHub user `dangirsh <https://github.com/dangirsh/>`_
* GitHub user `RazerM <https://github.com/RazerM/>`_
* GitHub user `jdanbrown <https://github.com/jdanbrown/>`_
* GitHub user `@anntzer <https://github.com/anntzer>`_
* GitHub user `@crowsonkb <https://github.com/crowsonkb>`_
